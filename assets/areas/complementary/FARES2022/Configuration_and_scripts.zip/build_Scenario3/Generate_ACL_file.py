#!/usr/bin/env python3
from redis import StrictRedis
import sys, json
from os.path import dirname, realpath, join

''' Each vehicle has read, write, subsribe and readwrite ACLs
e.g., TI173PM, TI173PM:racls, TI173PM:wacls, TI173PM:sacls

ACL file should include
# <plate number>
user <plate number>
topic [read|write|readwrite|deny] <topic>
'''
def save(filename, file):
    with open(filename, 'w') as f:
        f.write(str(file))

dir=dirname(realpath(__file__))

try:
    redis = StrictRedis("<IP>", <Port>, password="...")
    ACL = ""
    if(redis.ping()):
        plates = redis.execute_command('KEYS', '*')
        for p in plates:
            p = p.decode()
            
            ACL += "#"+p+"\n"
            ACL += "user "+p+"\n"

            read_acls = redis.execute_command('SMEMBERS', p+':racls')
            
            write_acls = redis.execute_command('SMEMBERS', p+':wacls')

            readwrite_acls = redis.execute_command('SMEMBERS', p+':rwacls')

            if(read_acls):
                for r in read_acls:
                    ACL += "topic read "+r.decode()+"\n"
            if(write_acls):
                for r in write_acls:
                    ACL += "topic write "+r.decode()+"\n"
            if(readwrite_acls):
                for r in readwrite_acls:
                    ACL += "topic readwrite "+r.decode()+"\n"
            ACL += "\n\n"
    save(join(dir,"acl_file"), ACL)
except Exception as ex:
    print(ex)
    sys.exit()