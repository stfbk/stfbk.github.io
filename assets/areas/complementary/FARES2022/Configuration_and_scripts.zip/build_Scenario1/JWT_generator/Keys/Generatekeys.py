#!/usr/bin/env python3
from OpenSSL import crypto
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from os.path import dirname, realpath, join

def save(path_name, file):
    with open(path_name, 'wb+') as f:
        f.write(file)

dir=dirname(realpath(__file__))

#RSA - 3072
pk = crypto.PKey()
pk.generate_key(crypto.TYPE_RSA, 3072)

save(join(dir,"RSA_PrK"), crypto.dump_privatekey(crypto.FILETYPE_PEM, pk))
save(join(dir,"RSA_PuK"), crypto.dump_publickey(crypto.FILETYPE_PEM, pk))

#EC - P384
private_key = ec.generate_private_key(ec.SECP384R1())
private_key_pem = private_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.TraditionalOpenSSL, encryption_algorithm=serialization.NoEncryption())

public_key = private_key.public_key()
public_key_pem = public_key.public_bytes(encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo)


save(join(dir,"EC_PrK"), private_key_pem)
save(join(dir,"EC_PuK"), public_key_pem)