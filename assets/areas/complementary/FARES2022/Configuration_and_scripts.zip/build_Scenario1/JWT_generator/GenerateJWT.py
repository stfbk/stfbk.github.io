#!/usr/bin/env python3
import jwt
import ast
import os
import datetime
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from os.path import dirname, realpath, join, isfile

def load_private_key(path_name):
    with open(path_name, "rb") as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None,
            backend=default_backend()
            )
    return private_key

def load(path_name):
    with open(path_name) as f:
        data = f.read()
    return data
def save(path_name, file):
    with open(path_name, 'w') as f:
        f.write(str(file))

def attributes_to_claims(attributes, jti):
    now = datetime.datetime.utcnow()
    claims = {
        "jti": "",
        "iss": "",
        "sub": "",
        "aud": "",
        "exp": now + datetime.timedelta(days=1),
        "nbf": now,
        "iat": now,
        "attributes": ""
    }
    attributes = ast.literal_eval(attributes)
    claims["jti"] = jti
    claims["iss"] = attributes["Manufacturer"]
    claims["sub"] = attributes["ID"]
    attributes.pop("ID", None) # Removes it as already in SUB
    claims["aud"] = "Automotive"
    claims["attributes"] = attributes
    return claims

dir=dirname(realpath(__file__))

for file in os.listdir(join(dir,"AttributesPolicyGen")):
    if file.endswith(".attributes") and len(file) == 18:
        # Increase the JWT ID
        filename = join(dir,"JWTs", file[0:7])
        if (isfile(filename+".JTI")):
            jti = int(load(filename+".JTI"))+1
        else:
            jti = 1
        save(filename+".JTI", jti)

        car_attributes = load(join(dir,"AttributesPolicyGen", file))
        claims = attributes_to_claims(car_attributes, jti)

        RSA_JWT = jwt.encode(claims, load_private_key(join(dir,"Keys","RSA_PrK")), algorithm='RS256')
        save(filename +".RSAJWT",RSA_JWT)
        EC_JWT = jwt.encode(claims, load_private_key(join(dir,"Keys","EC_PrK")), algorithm='ES384')
        save(filename +".ECJWT", EC_JWT)