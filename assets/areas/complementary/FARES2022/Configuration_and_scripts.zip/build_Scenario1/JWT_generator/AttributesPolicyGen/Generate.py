#!/usr/bin/env python3
import random
import uuid
import json
from string import ascii_uppercase
from os.path import dirname, realpath, join

def gen_MEC_attributes(ID):
    # 1 or more of the following attribute values
    MEC_SP = random.sample(["SP1","SP2","SP3"], random.randint(1,3))
    MEC_Region = random.sample(["RegionA","RegionB","RegionC"], random.randint(1,3))
    MEC_MNO = random.sample(["MNO1","MNO2","MNO3"], random.randint(1,3))
    attributes = {
        "ID":ID, 
        "SP":MEC_SP, 
        "Region":MEC_Region, 
        "MNO":MEC_MNO
    }
    return attributes

def gen_vehicle_attributes(ID):
    # Emergency vehicles are forced to 'Secure' and 'High_priority'
    V_SP = random.sample(["SP1","SP2","SP3"], random.randint(1,3))
    V_Region = random.sample(["RegionA","RegionB","RegionC"], random.randint(1,3))
    V_MNO = random.choice(["MNO1","MNO2","MNO3"]) # Only one
    V_Type = random.choice(['Normal','Emergency']) # Only one
    V_Data_flow = random.sample(['Source','Destination'], random.randint(1,2))
    #V_Data_flow = ['Source','Destination'] # Uncomment to save both
    V_Notification = ['Critical']
    if (random.randint(1,2)>1):
        V_Notification.append('Generic') 
    
    attributes = {
        "ID":ID,
        "Manufacturer": random.choice(['Fiat', 'Audi', 'BMW']),
        "SP":V_SP, 
        "Region":V_Region, 
        "MNO":V_MNO, 
        "Type":V_Type, 
        "Emergency_type" : random.choice(['Ambulance', 'Police']) if("Emergency" in V_Type) else [],
        "Data_flow":V_Data_flow, 
        "Data_type":['Sensitive','Non_sensitive'] if("Emergency" in V_Type) else random.sample(['Sensitive','Non_sensitive'], random.randint(1,2)), 
        "Channel": ['Secure'] if("Emergency" in V_Type) else random.sample(['Secure','Non_secure'], random.randint(1,2)), 
        "Priority":['High_priority'] if("Emergency" in V_Type) else random.sample(['Normal','High_priority'], random.randint(1,2)),
        "Notification":V_Notification,
        "Notification_topic" : random.sample(['Petrol Stations','POI', 'Restaurants', 'Transports','Speed Cameras','Average Speed Control'], random.randint(1,6)) if("Generic" in V_Notification) else []
    }
    return attributes

def gen_vehicle_policy_new(attributes):
    Data_flow, Channel, Priority, Data_type = {}, {}, {}, {}
    Topic = []

    for _n in attributes['Notification']:
        if (_n == "Critical"):
            Topic.append("Critical")
        else:
            for _nt in attributes['Notification_topic']:
                Topic.append(_n+"/"+_nt)

    for _d in attributes['Data_type']:
        Data_type[_d] = Topic
        for _p in attributes['Priority']:
            Priority[_p] = Data_type
            for _c in attributes['Channel']:
                Channel[_c] = Priority
                for _f in attributes['Data_flow']:
                    Data_flow[_f] = Channel
    return Data_flow                
       
def random_plate():
    return random.choice(ascii_uppercase) + random.choice(ascii_uppercase) + str(random.randint(100, 1000)) + random.choice(ascii_uppercase) + random.choice(ascii_uppercase)

def save(path_name, file):
    with open(path_name, 'w') as f:
        f.write(json.dumps(file))
        
##MEC/Edge_devices or the Cloud broker do not participate in the evaluation; hence skipped
##ITS_S = ['MEC','Vehicle','Core','Middleware_IoT']

#MEC_ID = str(uuid.uuid4()) # random UUID
#MEC_attributes = gen_MEC_attributes(MEC_ID)

#save(MEC_ID+".attributes", MEC_attributes)

Vehicle_ID = random_plate() # random plate number (format "BG122SN")
v_attributes = gen_vehicle_attributes(Vehicle_ID)
v_policy = gen_vehicle_policy_new(v_attributes)

dir=dirname(realpath(__file__))
save(join(dir,Vehicle_ID+".attributes"),v_attributes)
save(join(dir,Vehicle_ID+".policy"),v_policy)