#!/usr/bin/env python3 
import random
import json
from string import ascii_uppercase
from os.path import dirname, realpath, join

#Example of the most complete attribute and policy files (for an emergency vehicle)

def gen_vehicle_attributes(ID):
    #Random sets of attributes (to choose from with random)
    V_SP = ["SP1","SP2","SP3"]
    V_Region = ["RegionA","RegionB","RegionC"]
    V_MNO = "MNO1"
    V_Type = 'Emergency'
    V_Data_flow = ['Source','Destination']
    V_Notification = ['Critical','Generic']
    
    attributes = {
        "ID":ID,
        "Manufacturer": random.choice(['Fiat', 'Audi', 'BMW']),
        "SP":V_SP, 
        "Region":V_Region, 
        "MNO":V_MNO, 
        "Type":V_Type, 
        "Emergency_type" : random.choice(['Ambulance', 'Police']) if("Emergency" in V_Type) else [],
        "Data_flow":V_Data_flow, 
        "Data_type":['Sensitive','Non_sensitive'], 
        "Channel": ['Secure','Non_secure'], 
        "Priority":['High_priority','Normal'],
        "Notification":V_Notification,
        "Notification_topic" : ['Petrol Stations','POI', 'Restaurants', 'Transports','Speed Cameras','Average Speed Control']
    }
    return attributes

def gen_vehicle_policy(attributes):
    Data_flow, Channel, Priority, Data_type = {}, {}, {}, {}
    Topic = []

    for _n in attributes['Notification']:
        if (_n == "Critical"):
            Topic.append("Critical")
        else:
            for _nt in attributes['Notification_topic']:
                Topic.append(_n+"/"+_nt)

    for _d in attributes['Data_type']:
        Data_type[_d] = Topic
        for _p in attributes['Priority']:
            Priority[_p] = Data_type
            for _c in attributes['Channel']:
                Channel[_c] = Priority
                for _f in attributes['Data_flow']:
                    Data_flow[_f] = Channel
    return Data_flow                
       
def random_plate():
    # random plate number (format "BG122SN")
    return random.choice(ascii_uppercase) + random.choice(ascii_uppercase) + str(random.randint(100, 1000)) + random.choice(ascii_uppercase) + random.choice(ascii_uppercase)

def save(path_name, file):
    with open(path_name, 'w') as f:
        f.write(json.dumps(file))

Vehicle_ID = random_plate() 
v_attributes = gen_vehicle_attributes(Vehicle_ID)
v_policy = gen_vehicle_policy(v_attributes)

dir=dirname(realpath(__file__))
save(join(dir,Vehicle_ID+".complete.attributes"),v_attributes)
save(join(dir,Vehicle_ID+".complete.policy"),v_policy)