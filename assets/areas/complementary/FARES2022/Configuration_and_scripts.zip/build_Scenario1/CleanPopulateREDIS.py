#!/usr/bin/env python3
import json
from redis import StrictRedis
import sys
import os
from os.path import dirname, realpath, join, isfile

def load(filename):
    with open(filename) as f:
        data = f.read()
    return data
    
def create_general_policy():
    return {
    "Data_flow":{
        "Source":{
            "Normal":{
                ##REGION(same=true/different=False), SP (T/F), MNO (T/F), 
                ##Emergency_type, Manufacturer, Channel, Priority, Data_type, Topic
                "1": [None, None, None, [], [], [], [], ["Non_sensitive"], []],
                "2": [None, None, None, [], [], ["Secure"], [], ["Sensitive"], []]  
                },
            "Emergency":{
                "1": [True, None, None, [], [], [], ["High_priority", None], [], []],
                "2": [False, None, None, [], [], ["Secure"], ["High_priority"], [], []]
                }
            },
        "Destination":
            {
            "Normal":{
                ##REGION(same=true/different=False), SP (T/F), MNO (T/F), 
                ##Emergency_type, Manufacturer, Channel, Priority, Data_type, Topic
                "1": [None, None, None, [], [], [], [], [], ["Critical"]]
                },
            "Emergency":{
                "1": [None, None, None, [], [], [], [], [], ["Critical"]]
                }
            }
        },
        "Special":{
            "1": "datetime.time(8, 0, 0) <= datetime.datetime.now().time() <= datetime.time(20, 0, 0)",
            "2": "datetime.date.today().weekday()<=4"
            }
        }

try:
    redis = StrictRedis("<IP>", <PORT>, password="..")
    redis.ping()
    redis.flushall()
except:
    print("Unable to connect to REDIS - Exit")
    sys.exit()

dir=dirname(realpath(__file__))

RSA_PuK=load(join(dir,"JWT_generator","Keys","RSA_PuK"))
EC_PuK=load(join(dir,"JWT_generator","Keys","EC_PuK"))
keys = {"RSA": RSA_PuK, "EC": EC_PuK}

manufacturers = {}
for m in ["Audi", "Fiat", "BMW"]:
    manufacturers [m] = keys
redis.execute_command('JSON.SET', 'Manufacturers', '.', json.dumps(manufacturers))

for file in os.listdir(join(dir,"JWT_generator", "JWTs")):
    if file.endswith(".JTI"):
        filename = file[0:7]
        
        jti = {"jti": int(load(join(dir,"JWT_generator","JWTs",filename+".JTI")))}
        attributes = load(join(dir,"JWT_generator","AttributesPolicyGen",filename+".attributes"))
        attributes = {"attributes" : json.loads(attributes)}
        policy = load(join(dir,"JWT_generator","AttributesPolicyGen",filename+".policy"))
        policy = {"policies" : json.loads(policy)}
        entry = {**keys, **jti, **attributes, **policy}
        
        redis.execute_command('JSON.SET', filename, '.', json.dumps(entry))
        redis.execute_command('EXPIRE', filename, 86400)

redis.execute_command('JSON.SET', 'Policies', '.', json.dumps(create_general_policy()))

redis.connection_pool.disconnect()
