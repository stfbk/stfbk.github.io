#!/usr/bin/python
import OpenSSL
import argparse
import socket
import os

def exists(path, output):
    if os.path.exists(path):
        print (output)
        return True
    else:
        return False
    
def load_ca_files(ca_crt_filename, ca_key_filename):
    if not exists(ca_crt_filename, "CA Certificate - OK") or not exists(ca_key_filename, "CA Key - OK"):
        return None
    else:
        with open(ca_crt_filename, "r") as ca_cert_file:
            ca_cert_text = ca_cert_file.read()
            ca_cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, ca_cert_text)
        with open(ca_key_filename, "r") as ca_key_file:
            ca_key_text = ca_key_file.read()
            ca_key = OpenSSL.crypto.load_privatekey(OpenSSL.crypto.FILETYPE_PEM, ca_key_text)
        return [ca_cert,ca_key]

def getIP():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8",80))
    return s.getsockname()[0]    
    
def generate_key_crt(path, name, IP, ca_crt, ca_key):
    keypath = path + name + ".key"
    crtpath = path + name + ".crt"
    
    #if exists(keypath, ClientID + " key exists, skipping."):
    #    return
    #if exists(crtpath, ClientID + " certificate exists, skipping."):
    #    return
                                 
    # create public/private key
    key = OpenSSL.crypto.PKey()
    key.generate_key(OpenSSL.crypto.TYPE_RSA, 2048)
    
    # Generate CRT
    cert = OpenSSL.crypto.X509()
    cert.get_subject().CN = IP
    cert.set_serial_number(1)
    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(60 * 60 * 24 * 365 * 1) # 1 years
    cert.set_issuer(ca_crt.get_subject())
    cert.set_pubkey(key)
    cert.sign(ca_key, "sha256")
    
    with open(crtpath, 'wb+') as f:
        f.write(OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, cert))
    print(crtpath + " generated")
    with open(keypath, 'wb+') as f:
        f.write(OpenSSL.crypto.dump_privatekey(OpenSSL.crypto.FILETYPE_PEM, key))
    print(keypath + " generated")

parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('-p', '--path', dest='path', default = "", type=str, help='Specify path to the certs folder. Defaults to ""')
parser.add_argument('-n', '--name', dest='name', default = "server", type=str, help='Specify name for the certificate and key. Defaults to "server"')
args = parser.parse_args()

ca_files = load_ca_files(args.path + "ca.crt", args.path + "ca.key")

if(ca_files != None):
    IP = getIP() # Output is provided also if destination is unreachable
    generate_key_crt(args.path, args.name, IP, ca_files[0], ca_files[1])
else:
    print("Some error occurred")

