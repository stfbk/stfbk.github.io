for run in {1..10}; do
  mosquitto_pub -h <IP> -p 1883 -V mqttv5 -q 1 -t 'secure/high-priority/non-sensitive/warning' -m $(date +%s.%N)
  sleep 1
done