for run in {1..10}; do
  mosquitto_pub -h <IP> -p 8883 -q 1 -V mqttv5 --cafile 'ca.crt' -t 'secure/high-priority/non-sensitive/warning' -m $(date +%s.%N)
  sleep 1
done