#!/usr/bin/env python3
import os

def load(filename):
    with open(filename) as f:
        data = f.read()
    return data

i = 1
path = "../build_Scenario1/JWT_generator/JWTs"

for filename in os.listdir(path):
    if filename.endswith(".RSAJWT"):
        plate = filename[0:7]
        jwt = load(path + "/" + filename)

        print(f"mosquitto_sub -h <IP> -p 8001 -q 1 --cafile 'certs/ca.crt' --cert 'certs/{plate}.crt' --key 'certs/{plate}.key' -t '+/+/+/Secure/High_priority/Sensitive/Critical' -C 10 -F =%U-%p > 8001_3.1.1_600B-{i} &")

        #8001_3.1.1.1660B

        if (i%5==0):
            print ("\n\n\n")
        i += 1

