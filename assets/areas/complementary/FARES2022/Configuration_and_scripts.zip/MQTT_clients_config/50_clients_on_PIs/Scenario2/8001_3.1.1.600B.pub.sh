
for run in {1..10}; do
  mosquitto_pub -h <IP> -p 8001 -q 1 -i LS723VB --cafile '../build_Scenario2/certs/ca.crt' --cert '../build_Scenario2/certs/LS723VB.crt' --key '../build_Scenario2/certs/LS723VB.key' -t 'any/any/any/Secure/High_priority/Sensitive/Critical' -m $(date +%s.%N)_$(printf 'A%.0s' {1..579})
  sleep 1
done