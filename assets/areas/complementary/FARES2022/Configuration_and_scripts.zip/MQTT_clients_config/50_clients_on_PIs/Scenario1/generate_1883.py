for i in range (0,50):
    if (not (i)%5):
        print("")
    print (f"mosquitto_sub -h <IP> -p 1883 -q 1 -V mqttv311 -t '#' -C 10 -F =%U-%p > 1883_3.1.1-{i+1} &")
