#!/usr/bin/env python3
import OpenSSL
from redis import StrictRedis

from os.path import dirname, realpath, join, exists

def connect_redis():
    '''redis = StrictRedis(host='<IP>', port=<Port>, 
        ssl=True, password = '...',
        ssl_keyfile='../redis-stable/tests/tls/redis.key',
        ssl_certfile='../redis-stable/tests/tls/redis.crt',
        ssl_ca_certs='../redis-stable/tests/tls/ca.crt')'''
    redis = StrictRedis("<IP>", <Port>, password="..")
    return redis
    
def load_ca_files(ca_crt_pathname, ca_key_pathname):
    if not exists(ca_crt_pathname) or not exists(ca_key_pathname):
        return None
    else:
        with open(ca_crt_pathname, "r") as ca_cert_file:
            ca_cert_text = ca_cert_file.read()
            ca_cert = OpenSSL.crypto.load_certificate(OpenSSL.crypto.FILETYPE_PEM, ca_cert_text)
        with open(ca_key_pathname, "r") as ca_key_file:
            ca_key_text = ca_key_file.read()
            ca_key = OpenSSL.crypto.load_privatekey(OpenSSL.crypto.FILETYPE_PEM, ca_key_text)
        return [ca_cert,ca_key]
   
def generate_key_crt(path, name, ca_crt, ca_key):
    keypath = join(path, name + ".key")
    crtpath = join(path, name + ".crt")
                         
    # create public/private key
    key = OpenSSL.crypto.PKey()
    key.generate_key(OpenSSL.crypto.TYPE_RSA, 3096)
    
    # Generate CRT
    cert = OpenSSL.crypto.X509()
    cert.get_subject().CN = name
    cert.set_serial_number(1)
    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(60 * 60 * 24 * 365 * 1) # 1 years
    cert.set_issuer(ca_crt.get_subject())
    cert.set_pubkey(key)
    cert.sign(ca_key, "sha256")
    
    with open(crtpath, 'wb+') as f:
        f.write(OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, cert))
    with open(keypath, 'wb+') as f:
        f.write(OpenSSL.crypto.dump_privatekey(OpenSSL.crypto.FILETYPE_PEM, key))
        
    print(name + " credentials generated")

dir=dirname(realpath(__file__))

ca_files = load_ca_files(join(dir,"certs","ca.crt"), join(dir,"certs", "ca.key"))
redis = connect_redis()

if(ca_files != None and redis.ping()):
    entries = redis.execute_command('KEYS', '*') # Fetch all keys
    
    for e in entries:
        e = e.decode()
        if(e.endswith("acls") or e in ["Manufacturers", "Policies"]):
            continue
        else:
            generate_key_crt(join(dir,"certs"), e, ca_files[0], ca_files[1])
else:
    print("Some error occurred")


