#!/usr/bin/env python3
from redis import StrictRedis
import sys, json, ast

''' Expected to Read
<Vehicle>
{"Source":{
      "Secure":{
         "High_priority":{
            "Sensitive":["Critical",".."],
            "Non_sensitive":["Critical",".."]},
         "Normal":{
            "Sensitive":["Critical",".."],
            "Non_sensitive":["Critical",".."]}
      },
      "Non_secure":{
         "High_priority":{
            "Sensitive":["Critical",".."],
            "Non_sensitive":["Critical",".."]},
         "Normal":{
            "Sensitive":["Critical",".."],
            "Non_sensitive":["Critical",".."]}
      }
   },
   "Destination":{
      "Secure":{
         "High_priority":{
            "Sensitive":["Critical",".."],
			"Non_sensitive":["Critical",".."]},
         "Normal":{
            "Sensitive":["Critical",".."],
            "Non_sensitive":["Critical",".."]}
      },
      "Non_secure":{
         "High_priority":{
            "Sensitive":["Critical",".."],
            "Non_sensitive":["Critical",".."]},
         "Normal":{
            "Sensitive":["Critical",".."],
            "Non_sensitive":["Critical",".."]
}}}}
<General>
{"Data_flow":{
   "Source":{
                     #Region(same=true/different=False), SP (same..), MNo (same..), 
                     Emergency_type, Manufacturer, Channel, Priority, Data_type, Topic
      "Normal":{"1":[null,null,null,[],[],[],[],["Non_sensitive"],[]],
         "2":[null,null,null,[],[],["Secure"],[],["Sensitive"],[]]},
      "Emergency":{"1":[true,null,null,[],[],[],["High_priority",   null],[],[]],
         "2":[false,null,null,[],[],["Secure"],["High_priority"],[],[]]}
   },
   "Destination":{
      "Normal":{"1":[null,null,null,[],[],[],[],[],["Critical"]]},
      "Emergency":{"1":[null,null,null,[],[],[],[],[],["Critical"]]}}
   },"Special":{"1":"..", "2":".."}}
'''

def vehicle_acls(key, policies, general_acls):
    global redis
    
    vehicle_type = json.loads(redis.execute_command("JSON.GET", key, "attributes.Type"))
    
    for _f in policies: 
        #print(f"_f:  {_f}") #Flow: Source/Destination
        for _c in policies[_f]: 
            #print(f"_c:  {_c}") #Channel: Secure/Non_secure
            for _p in policies[_f][_c]: 
                #print(f"_p:  {_p}") #Priority: Normal/High_priority
                for _d in policies[_f][_c][_p]: 
                    #print(f"_d:  {_d}") #Datatype: Sensitive/Non_sensitive
                    for _t in policies[_f][_c][_p][_d]: 
                        #print(f"_t:  {_t}") #Topic: 'Critical' or else
                        if _f == 'Source':
                            #print(f"SADD {key}:wacls", f"+/+/+/{_c}/{_p}/{_d}/{_t}")
                            redis.execute_command("SADD", f"{key}:wacls", f"+/+/+/{_c}/{_p}/{_d}/{_t}")

                            if(general_acls.get(vehicle_type+':wacls')): #Add if not empty
                                for acl in general_acls.get(vehicle_type+":wacls"):
                                    #print(f"wacls ACL: {acl}\n")
                                    redis.execute_command("SADD", f"{key}:wacls", acl)
                                    
                        elif _f == 'Destination':
                            #print(f"SADD {key}:racls", f"+/+/+/{_c}/{_p}/{_d}/{_t}")
                            redis.execute_command("SADD", f"{key}:racls", f"+/+/+/{_c}/{_p}/{_d}/{_t}")
                            
                            if(general_acls.get(vehicle_type+":racls")):
                                for acl in general_acls.get(vehicle_type+":racls"):
                                    #print(f"racls ACL: {acl}\n")
                                    redis.execute_command("SADD", f"{key}:racls", acl)
                                    redis.execute_command("SADD", f"{key}:sacls", acl)
                        else:
                            #print(f"SADD {key}:rwacls", f"+/+/+/{_c}/{_p}/{_d}/{_t}")
                            redis.execute_command("SADD", f"{key}:rwacls", f"+/+/+/{_c}/{_p}/{_d}/{_t}")
                            
                            if(general_acls.get(vehicle_type+":rwacls")):
                                for acl in general_acls.get(vehicle_type+":rwacls"):
                                    #print(f"rwacls ACL: {acl}\n")
                                    redis.execute_command("SADD", f"{key}:rwacls", acl)

def new_values_or_wildcard(redis_value, new_values):
    if (redis_value): #True
        return new_values
    else: #False or Null
        return ["+"]
 
def general_acls(general_pol):
    general = {}
    for _f in general_pol['Data_flow']: 
        #print(f"_f:  {_f}") #Flow: Source/Destination
        for _type in general_pol['Data_flow'][_f]: 
            #print(f"_type:  {_type}") # Type Normal/Emergency

            if(_type+":racls" not in general): #Avoid overwriting on the second loop
                general[_type+":racls"] = []
                general[_type+":wacls"] = []
                general[_type+":rwacls"] = []
            
            for _r in general_pol['Data_flow'][_f][_type]: # Rules: 1, 2, ..
                rule = general_pol['Data_flow'][_f][_type][_r]
                same_region, same_sp, same_mno  = rule[0], rule[1], rule[2]
                e_type, manuf, ch, p, data_type, topic = rule[3], rule[4], rule[5], rule[6], rule[7], rule[8]
                
                regions = new_values_or_wildcard(same_region,["RegionA","RegionB","RegionC"])
                sps = new_values_or_wildcard(same_sp,["SP1","SP2","SP3"])
                mnos = new_values_or_wildcard(same_mno,["MNO1","MNO2","MNO3"])
                
                ch = new_values_or_wildcard(ch,ch)
                p = new_values_or_wildcard(p,p)
                data_type = new_values_or_wildcard(data_type,data_type)
                topic = new_values_or_wildcard(topic,topic)
                
                for _r in regions:
                    #print(f"_r:  {_r}") #Regions
                    for _s in sps:
                        #print(f"_s:  {_s}") #SPs
                        for _m in mnos:
                            #print(f"_m:  {_m}") #MNOs
                            for _c in ch: 
                                #print(f"_c:  {_c}") #Channel: Secure/Non_secure
                                for _p in p: 
                                    #print(f"_p:  {_p}") #Priority: Normal/High_priority
                                    for _d in data_type: 
                                        #print(f"_d:  {_d}") #Datatype: Sensitive/Non_sensitive
                                        for _t in topic: 
                                            #print(f"_t:  {_t}") #Topic: 'Critical' or else
                                            if _f == 'Source':
                                                #print(f"{_type}:wacls -> {_r}/{_s}/{_m}/{_c}/{_p}/{_d}/{_t}")
                                                general.get(_type+":wacls").append(f"{_r}/{_s}/{_m}/{_c}/{_p}/{_d}/{_t}")
                                            elif _f == 'Destination':
                                                #print(f"{_type}:racls -> {_r}/{_s}/{_m}/{_c}/{_p}/{_d}/{_t}")
                                                general.get(_type+":racls").append(f"{_r}/{_s}/{_m}/{_c}/{_p}/{_d}/{_t}")
                                            else:
                                                #print(f"{_type}:rwacls -> {_r}/{_s}/{_m}/{_c}/{_p}/{_d}/{_t}")
                                                general.get(_type+":rwacls").append(f"{_r}/{_s}/{_m}/{_c}/{_p}/{_d}/{_t}")
    return general
    
try:
    redis = StrictRedis("<IP>", <Port>, password="..")
    if(redis.ping()):
    
        #Flush previous ACLs
        for key in redis.scan_iter("*acls"):
            redis.delete(key)

        #Process general policies
        raw_general_pol = redis.execute_command('JSON.GET', 'Policies')
        if(raw_general_pol):
            general_pol = json.loads(raw_general_pol)
            general_acls = general_acls(general_pol)
            #print(f"general_acls -> \n{general_acls}\n\n")
            
        #Process specific policies
        entries = redis.execute_command('KEYS', '*') # Fetch all keys
        for key in entries:
            try:
                key = key.decode()
                entry = json.loads(redis.execute_command('JSON.GET', key))
                vehicle_acls(key, entry['policies'], general_acls)
            except KeyError:
                pass
except Exception as ex:
    print(ex)
    sys.exit()