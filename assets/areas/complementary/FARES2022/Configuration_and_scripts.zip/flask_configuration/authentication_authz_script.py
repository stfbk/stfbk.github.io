#!/usr/bin/env python3
from flask import Flask, jsonify, make_response, request
from flask_expects_json import expects_json
from redis import StrictRedis
from time import sleep
import datetime
import json
import jwt
import os

app = Flask(__name__)

authentication_request_schema = {
  "type": "object",
  "properties": {
    "username": { "type": "string" },
    "password": { "type": "string" },
    "clientid": { "type": "string" }
  },
  "required": ["clientid"]
}
authorization_request_schema = {
  "type": "object",
  "properties": {
    "topic": { "type": "string" },
    "clientid": { "type": "string" },
    "acc": { "type": "number" }
  },
  "required": ["topic", "clientid", "acc"]
}

def connect_redis():
    '''redis = StrictRedis(host='<IP>', port=<Port>, 
        ssl=True, password = '..',
        ssl_keyfile='..redis-stable/tests/tls/redis.key',
        ssl_certfile='..redis-stable/tests/tls/redis.crt',
        ssl_ca_certs='..redis-stable/tests/tls/ca.crt')'''
    redis = StrictRedis('<IP>', <Port>, password="..")
    return redis

def authenticate_eval(redis, clientID, password):
    '''Expected to receive ->{
    "RSA":"-----BEGIN PUBLIC KEY-----\nMIIAE=\n-----END PUBLIC KEY-----\n",
    "EC":"-----BEGIN PUBLIC KEY-----\nMHYyp\n-----END PUBLIC KEY-----\n",
    "jti":1,
    "attributes":{"Notification": [".."], "Region": [".."], "Emergency_type": "..", "Priority": [".."], "Notification_topic": [".."], "Type": "..", "ID": "..", "Channel": [".."], "Data_type": ["."], "SP": ["."], "MNO": "..", "Data_flow": [".."], "Manufacturer": ".."},
    "policy":{"Priority": 2, "Data_type": 3, "Channel": 2, "Notification_topics": [".."]}
    }'''
    try:
        #Extracts the algorithm and the issuer (to fetch the public key to use to validate the JWT)
        alg = jwt.get_unverified_header(password)['alg']
        redis_alg = 'RSA' if (alg == "RS256") else 'EC'
        iss = jwt.decode(password, options = {"verify_signature": False})["iss"]
        
        #Verify if the issuer is among the manufacturers; if so fetch its publickey, otherwise look for the vehicle specific
        #public key (the one associated with the user CIE and stored in REDIS)
        public_key = redis.execute_command('JSON.GET', 'Manufacturers', f"{iss}.{redis_alg}")
        if (public_key is None):
            #If here, the issuer is not a manufacturer or the manufacturer public key is not present; search for the vehicle
            public_key = redis.execute_command('JSON.GET', iss,  redis_alg)
            
        #Parse the public key and use it to verify the JWT - raises exception in case of errors/expiry..
        public_key = json.loads(public_key)
        decoded_jwt = jwt.decode(password, public_key, algorithms=[alg], audience= "Automotive", options={"require": ["exp", "iss", "sub"]})  
        #Using 'alg' variable is reported as an issue in pyJWT doc - decided to leave it instead of hardcoding the algorithm for the tests
        
        #Fetch the vehicle in the database (to eventually update the jti) or put an entry with the JWT jti
        raw_redis_data = redis.execute_command('JSON.GET', clientID)
        if(raw_redis_data is None):
            #If here, the vehicle has a JWT signed by the manufacturer but no vehicle entry in in REDIS
            jti = {"jti" : decoded_jwt['jti']}
            key = {redis_alg : public_key}
            attributes = {"attributes" : decoded_jwt['attributes']}
            redis.execute_command('JSON.SET', clientID, '.', json.dumps({**key, **attributes, **jti}))
        else:
            #If here, update the vehicle entry jti or return if re-using an old JWT
            redis_data = json.loads(raw_redis_data)
            if (decoded_jwt['jti']<redis_data['jti']):
                return "C: Not the latest provided token"
            else:
                redis.execute_command('JSON.SET', clientID, '.attributes', json.dumps(decoded_jwt['attributes']))
        #The vehicle entry expires after 1 day
        redis.execute_command('EXPIRE', clientID, 86400)
    except jwt.ExpiredSignatureError:
        return "C: Expired JWT"
    except jwt.exceptions.InvalidSignatureError:
        return "C: Invalid signature"
    except Exception as e:
       print (e)
       return "S: Error while parsing the JWT"    
    return 0

@app.route("/authenticate", methods=['POST'])
@expects_json(authentication_request_schema)
def authenticate():
    global redis
    
    req_data = request.get_json()
    #print(f"\nAuthentication request: {req_data}")
    
    result = authenticate_eval(redis, req_data['clientid'], req_data['password'])
    print(f"{req_data['clientid']} authentication = {result}")

    if result == 0:
        return make_response(jsonify({'Ok': True}), 200, {"Content-Type": "application/json"} )
    elif result[0]=="C":
        return make_response(jsonify({'Ok': False, 'Error': 'Not Authorized', 'description': result}), 401, {"Content-Type": "application/json"})
    else:
        return make_response(jsonify({'Ok': False, 'Error': 'Server error'}), 500, {"Content-Type": "application/json"})

def var_in_env(list, env_variable):
    test = False
    for r_m_s in list:
        if r_m_s in env_variable:
            test = True
    return test

def value_eval(value, condition):
    if (value or type(value)==bool): #Not None
        return True if condition else False 
    else:
        return True #None = "Any" = True

def general_eval(redis, acc, client_attributes, Channel, Priority, Data_type, trail):
    global MNOS
    global SPS
    global REGIONS

    r = True if(var_in_env(client_attributes['Region'], REGIONS)) else False #Region corresponds or included in the running MEC
    s = True if(var_in_env(client_attributes['SP'], SPS)) else False #SP corresponds or included in the running MEC
    m = True if(client_attributes['MNO'] not in MNOS) else False #MNO corresponds or included in the running MEC

    Type = client_attributes['Type']
    Manufacturer = client_attributes['Manufacturer'] 
    Emergency_type = client_attributes['Emergency_type'] if 'Emergency_type' in client_attributes else None
    
    raw_redis_data = redis.execute_command('JSON.GET', "Policies", f"Data_flow.{acc}.{Type}")
    policies = json.loads(raw_redis_data)
        
    result_list = []
    #p = [Region, SP, MNO, Emergency_type, Manufacturer, Channel, Priority, Data_type, Topic]
    for p in policies.values():
        #print(f"-- -- P vector: {p}")
        #print(f"-- -- -- 'p[0]'={p[0]}, 'r'={r}")
        _0 = value_eval(p[0], p[0] == r)
        _1 = value_eval(p[1], p[1] == s)
        _2 = value_eval(p[2], p[2] == m)
        #Flow and type are evaluated implicitly by fetching the subset of policies (via acc and client_attributes['Type']) 
        _3 = value_eval(p[3], Emergency_type in p[3])
        _4 = value_eval(p[4], Manufacturer in p[4])
        _5 = value_eval(p[5], Channel in p[5])
        _6 = value_eval(p[6], Priority in p[6]) #Priority rule
        _7 = value_eval(p[7], Data_type in p[7]) #Data_type rule
        
        if (_0 and _1 and _2 and _3 and _4 and _5 and _6 and _7):
            if (value_eval(p[8], trail in p[8])): #Rule is applicable, check if topic is in the list of allowed ones or "None" -> Any
                result_list.append(True)
                #print(f"-- -- EVAL vector: {[_0, _1, _2, _3, _4, _5, _6, _7]}")
                #print("-- --  Subresult True!")
            else:
                result_list.append(False)
                #print(f"-- -- EVAL vector: {[_0, _1, _2, _3, _4, _5, _6, _7]}")
                #print("-- -- Subresult False!")
    if result_list:
        if False in result_list:
            return False
        else:
            return True
    else: #No applicable rules
        return None
        
def authorize_eval(redis, clientID, topic, acc):
    global MNOS
    global SPS
    global REGIONS
    '''
    acc -> 1 is read, 2 is write, 3 is readwrite, 4 is subscribe
    topic -> [Secure, Non-secure] / [Normal, High-priority] / [Sensitive, Non-sensitive] / [Generic/[Notif.Topics], Critical]
    raw_redis_data ->{
    "RSA":"-----BEGIN PUBLIC KEY-----\nMIIAE=\n-----END PUBLIC KEY-----\n",
    "EC":"-----BEGIN PUBLIC KEY-----\nMHYyp\n-----END PUBLIC KEY-----\n",
    "jti":1,
    "attributes":{"Notification": [".."], "Region": [".."], "Emergency_type": "..", "Priority": [".."], 
        "Notification_topic": [".."],   "Type": "..", "ID": "..", "Channel": [".."], "Data_type": ["."], "SP": ["."], "MNO": "..", "Data_flow": [".."], "Manufacturer": ".."},
    "policy": SPECIFIC POLICY TREE
    }'''
    raw_redis_data = redis.execute_command('JSON.GET', clientID)
    if(raw_redis_data is None):
        #Key not locally present - Fetch it from where?
        return "S:key not present in Redis"
    else:
        #Parse the data and get attributes and policies
        redis_data = json.loads(raw_redis_data)
        attributes = redis_data['attributes']

    splitted_topic = topic.split("/")
    
    if(acc in [1,4]): #Receiving ("read" or "subscribe" access request)
        acc = "Destination"
    elif (acc == 2): #Publishing ("write" access request)
        acc = "Source"
    else: #acc == 3 corresponds to readwrite - never invoked by Mosquitto
        acc = None
    
    #Evaluate flow
    if(acc and acc not in attributes['Data_flow']):
        return "C: Client Data_flow does not corresponds"
    
    #print("-- Flow Eval = True")
    
    results = []
    Channel, Priority, Data_type, trail = splitted_topic[0], splitted_topic[1], splitted_topic[2], ''.join(splitted_topic[3:])
    #Evaluate specific policies
    try:
        if (trail in redis_data['policies'][acc][Channel][Priority][Data_type]):
            results.append(True)
            #print("-- Client Policy eval = True")
        else:
            results.append(False)
            #print("-- Client Policy eval = False")
    except:
        pass #In case the key does not exist
        #print("-- Client Policy eval skipped")

    #Evaluate general policies if no client-specific apply
    if(not results):
        results.append(general_eval(redis, acc, attributes, Channel, Priority, Data_type, trail))

    #print(f"-- After general policy eval Result = {results}")
    
    #Evaluate special rules (if a specific or general rule apply and True, and special rules are present)
    raw_redis_data = redis.execute_command('JSON.GET', "Policies", ".Special")
    if(True in results and raw_redis_data):
        special_rules = json.loads(raw_redis_data)
        for s in special_rules.values():
            results.append(eval(s))
        #print(f"-- After special rules eval Result = {results}")

    if True in results and not False in results:
        return 0
    else:
        return "C: Client is not authorised"

@app.route("/authorize", methods=['POST'])
@expects_json(authorization_request_schema)
def authorize():
    global redis
    
    req_data = request.get_json()
    #print(f"\nAuthentication request: {req_data}")
    
    result = authorize_eval(redis, req_data['clientid'], req_data['topic'], req_data['acc'])
    print(f"{req_data['clientid']} authorisation = {result}")

    if result== 0:
        return make_response(jsonify({'Ok': True}), 200, {"Content-Type": "application/json"} )
    elif result[0]=="C":
        return make_response(jsonify({'Ok': False, 'Error': 'Not Authorized'}), 401, {"Content-Type": "application/json"})
    else:
        return make_response(jsonify({'Ok': False, 'Error': 'Server error'}), 500, {"Content-Type": "application/json"})

if __name__ == '__main__':

    redis = connect_redis()
    try:
        if(redis.ping()):

            #curl --insecure --location --request POST 'localhost:5000/authorize' --header 'Content-Type: application/json' --data-raw '{"topic":"Testing_30_Attributes/test/3", "clientid": "Client_1", "acc": 4}'
            #curl --insecure --location --request POST 'localhost:5000/authenticate' --header 'Content-Type: application/json' --data-raw '{"username":"user1", "password": "pw1", "clientid": "cID"}'
            # Server certificate and key to enforce HTTPS
            #context = ('CERTS/flask.crt', 'CERTS/flask.key')

            #Set MEC env. variables - Should be set externally of Python (e.g., at boot)
            os.environ['Automotive_MNOS']='["MNO1","MNO2","MNO3"]'
            os.environ['Automotive_SPS']='["SP1","SP2","SP3"]'
            os.environ['Automotive_REGIONS']='["RegionA","RegionB","RegionC"]'
            
            MNOS = json.loads(os.environ['Automotive_MNOS'])
            SPS = json.loads(os.environ['Automotive_SPS'])
            REGIONS = json.loads(os.environ['Automotive_REGIONS'])
            
            #app.run(port=5000, ssl_context=context)
            app.run(debug=True, threaded=True, port=5000)
    except:
        print("Redis unreachable")
