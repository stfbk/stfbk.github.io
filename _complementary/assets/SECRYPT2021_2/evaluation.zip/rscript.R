
# clear the environment
rm(list=ls())

# modify here the path
path = 

# columns in CSV files
number = "number"
revokeU_1Parameter = "revokeU1"
revokeU_2Parameter = "revokeU2"
revokeU_3Parameter = "revokeU3"
revokeP_Parameter = "revokeP"
revokeU_1_lower = "revokeU1_lower"
revokeU_2_lower = "revokeU2_lower"
revokeU_3_lower = "revokeU3_lower"
revokeP_lower = "revokeP_lower"
revokeU_1_upper = "revokeU1_upper"
revokeU_2_upper = "revokeU2_upper"
revokeU_3_upper = "revokeU3_upper"
revokeP_upper = "revokeP_upper"

# colors
blue = "#2980b9"
red = "#e74c3c"
green = "#27ae60"
purple = "#8e44ad"
grey = "#95a5a6"
white = "#ffffff"
black = "#2c3e50"
orange = "#f39c12"
darkgreen = "#16a085"

# expected values
revokeU_Expected <- read.csv(paste(path, "revokeU_Expected.csv", sep=""))
expected_revokeU1_lower <- unlist(revokeU_Expected[revokeU_1_lower])
expected_revokeU2_lower <- unlist(revokeU_Expected[revokeU_2_lower])
expected_revokeU3_lower <- unlist(revokeU_Expected[revokeU_3_lower])

expected_revokeU1_upper <- unlist(revokeU_Expected[revokeU_1_upper])
expected_revokeU2_upper <- unlist(revokeU_Expected[revokeU_2_upper])
expected_revokeU3_upper <- unlist(revokeU_Expected[revokeU_3_upper])

revokeP_Expected <- read.csv(paste(path, "revokeP_Expected.csv", sep=""))
expected_revokeP_lower <- unlist(revokeP_Expected[revokeP_lower])
expected_revokeP_upper <- unlist(revokeP_Expected[revokeP_upper])



# ===== RevokeP  =====

revokeP_csv <- read.csv(paste(path, "revokeP.csv", sep=""))

xAxis <- unlist(revokeP_csv[number])
actual_revokeP <- unlist(revokeP_csv[revokeP_Parameter])

pdf(file = "revokeP.pdf")

plot(x = xAxis, y = actual_revokeP, ylim=c(0,4000), xlim=c(0,100), cex.axis = 1.5, cex.lab = 1.5, type = "n", xlab = "Number of Other Roles", ylab = "Execution Time (ms)")

lines(actual_revokeP, col = blue, lty=3, lwd = 1.5)
lines(expected_revokeP_lower, col = black, lty=2, lwd = 2.5)
text(80, -120, "2.34", cex=1.75, pos=3,col=black)

lines(expected_revokeP_upper, col = green, lty=5, lwd = 2.5)
text(80, 2400, "37.36", cex=1.75, pos=3,col=green)

abline(lm(actual_revokeP ~ xAxis), col = blue, lty = 1, lwd = 2.5)
model <- lm(actual_revokeP ~ xAxis)
summary(model)
model$coefficients
text(80, 400, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=blue)



legend(0, 4000, legend=c("Implementation Time", "Cryptographic Time", "Actual Execution Time", "Linear Regression on Actual Execution Time"),
       col=c(green, black, blue, blue), lty=c(5,2,3,1), lwd = 1.5)

dev.off()





# ===== RevokeU1  =====

revokeU1_csv <- read.csv(paste(path, "revokeU1.csv", sep=""))

xAxis <- unlist(revokeU1_csv[number])
actual_revokeU1 <- unlist(revokeU1_csv[revokeU_1Parameter])

pdf(file = "revokeU1.pdf")

plot(x = xAxis, y = actual_revokeU1, ylim=c(0,2000), xlim=c(0,100), cex.axis = 1.5, cex.lab = 1.5, type = "n", xlab = "Number of Users", ylab = "Execution Time (ms)")

lines(actual_revokeU1, col = blue, lty=3, lwd = 1.5)
lines(expected_revokeU1_lower, col = black, lty=2, lwd = 2.5)
text(80, 0, "2.76", cex=1.75, pos=3,col=black)

lines(expected_revokeU1_upper, col = green, lty=5, lwd = 2.5)
text(80, 1200, "19.42", cex=1.75, pos=3,col=green)

abline(lm(actual_revokeU1 ~ xAxis), col = blue, lty = 1, lwd = 2.5)
model <- lm(actual_revokeU1 ~ xAxis)
summary(model)
model$coefficients
text(80, 400, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=blue)

legend(0, 2000, legend=c("Implementation Time", "Cryptographic Time", "Actual Execution Time", "Linear Regression on Actual Execution Time"),
       col=c(green, black, blue, blue), lty=c(5,2,3,1), lwd = 1.5)

dev.off()




# ===== RevokeU2  =====

revokeU2_csv <- read.csv(paste(path, "revokeU2.csv", sep=""))

xAxis <- unlist(revokeU2_csv[number])
actual_revokeU2 <- unlist(revokeU2_csv[revokeU_2Parameter])

pdf(file = "revokeU2.pdf")

plot(x = xAxis, y = actual_revokeU2, ylim=c(0,2000), xlim=c(0,100), cex.axis = 1.5, cex.lab = 1.5, type = "n", xlab = "Number of Files", ylab = "Execution Time (ms)")

lines(actual_revokeU2, col = blue, lty=3, lwd = 1.5)
lines(expected_revokeU2_lower, col = black, lty=2, lwd = 2.5)
text(80, -20, "0.03", cex=1.75, pos=3,col=black)

lines(expected_revokeU2_upper, col = green, lty=5, lwd = 2.5)
text(80, 800, "9.87", cex=1.75, pos=3,col=green)

abline(lm(actual_revokeU2 ~ xAxis), col = blue, lty = 1, lwd = 2.5)
model <- lm(actual_revokeU2 ~ xAxis)
summary(model)
model$coefficients
text(80, 200, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=blue)

legend(0, 2000, legend=c("Implementation Time", "Cryptographic Time", "Actual Execution Time", "Linear Regression on Actual Execution Time"),
       col=c(green, black, blue, blue), lty=c(5,2,3,1), lwd = 1.5)

dev.off()





# ===== RevokeU3  =====

revokeU3_csv <- read.csv(paste(path, "revokeU3.csv", sep=""))

xAxis <- unlist(revokeU3_csv[number])
actual_revokeU3 <- unlist(revokeU3_csv[revokeU_3Parameter])

pdf(file = "revokeU3.pdf")

plot(x = xAxis, y = actual_revokeU3, ylim=c(0,2000), xlim=c(0,100), cex.axis = 1.5, cex.lab = 1.5, type = "n", xlab = "Number of Other Roles", ylab = "Execution Time (ms)")

lines(actual_revokeU3, col = blue, lty=3, lwd = 1.5)
lines(expected_revokeU3_lower, col = black, lty=2, lwd = 2.5)
text(80, 0, "2.34", cex=1.75, pos=3,col=black)

lines(expected_revokeU3_upper, col = green, lty=5, lwd = 2.5)
text(80, 600, "6.79", cex=1.75, pos=3,col=green)

abline(lm(actual_revokeU3 ~ xAxis), col = blue, lty = 1, lwd = 2.5)
model <- lm(actual_revokeU3 ~ xAxis)
summary(model)
model$coefficients
text(80, 200, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=blue)

legend(0, 2000, legend=c("Implementation Time", "Cryptographic Time", "Actual Execution Time", "Linear Regression on Actual Execution Time"),
       col=c(green, black, blue, blue), lty=c(5,2,3,1), lwd = 1.5)

dev.off()







# ===== RevokeU1_U2  =====

revokeU1_U2csv <- read.csv(paste(path, "revokeU1_U2.csv", sep=""))

xAxis <- unlist(revokeU1_U2csv[number])
revokeU1_100_U2 <- unlist(revokeU1_U2csv["revokeU1_100_U2"])
revokeU1_200_U2 <- unlist(revokeU1_U2csv["revokeU1_200_U2"])
revokeU1_300_U2 <- unlist(revokeU1_U2csv["revokeU1_300_U2"])

pdf(file = "revokeU1_U2.pdf")

plot(x = xAxis, y = revokeU1_300_U2, ylim=c(0,4000), xlim=c(0,100), cex.axis = 1.5, cex.lab = 1.5, type = "n", xlab = "Number of Users", ylab = "Execution Time (ms)")


lines(actual_revokeU1, col = blue, lty=3) 
abline(lm(actual_revokeU1 ~ xAxis), col = blue, lty = 1)
model <- lm(actual_revokeU1 ~ xAxis)
text(10, 100, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=blue)

lines(revokeU1_100_U2, col = green, lty=3)
abline(lm(revokeU1_100_U2 ~ xAxis), col = green, lty = 1)
model <- lm(revokeU1_100_U2 ~ xAxis)
text(10, 1300, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=green)

lines(revokeU1_200_U2, col = purple, lty=3)
abline(lm(revokeU1_200_U2 ~ xAxis), col = purple, lty = 1)
model <- lm(revokeU1_200_U2 ~ xAxis)
text(10, 2200, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=purple)

lines(revokeU1_300_U2, col = black, lty=3)
abline(lm(revokeU1_300_U2 ~ xAxis), col = black, lty = 1)
model <- lm(revokeU1_300_U2 ~ xAxis)
text(10, 2900, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=black)

legend(0, 4000, legend=c("Linear Regression With 1 Files", "Linear Regression With 100 Files", "Linear Regression With 200 Files", "Linear Regression With 300 Files"),
       col=c(blue, green, purple, black), lty=c(1,1,1,1))

dev.off()





# ===== RevokeU2_U3  =====

revokeU2_U3csv <- read.csv(paste(path, "revokeU2_U3.csv", sep=""))

xAxis <- unlist(revokeU2_U3csv[number])
revokeU2_100_U3 <- unlist(revokeU2_U3csv["revokeU2_100_U3"])
revokeU2_200_U3 <- unlist(revokeU2_U3csv["revokeU2_200_U3"])
revokeU2_300_U3 <- unlist(revokeU2_U3csv["revokeU2_300_U3"])

pdf(file = "revokeU2_U3.pdf")

plot(x = xAxis, y = revokeU2_300_U3, ylim=c(0,4000), xlim=c(0,100), cex.axis = 1.5, cex.lab = 1.5, type = "n", xlab = "Number of Files", ylab = "Execution Time (ms)")

lines(actual_revokeU2, col = blue, lty=3) 
abline(lm(actual_revokeU2 ~ xAxis), col = blue, lty = 1)
model <- lm(actual_revokeU2 ~ xAxis)
text(10, 70, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=blue)

lines(revokeU2_100_U3, col = green, lty=3)
abline(lm(revokeU2_100_U3 ~ xAxis), col = green, lty = 1)
model <- lm(revokeU2_100_U3 ~ xAxis)
text(10, 600, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=green)

lines(revokeU2_200_U3, col = purple, lty=3)
abline(lm(revokeU2_200_U3 ~ xAxis), col = purple, lty = 1)
model <- lm(revokeU2_200_U3 ~ xAxis)
text(10, 1030, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=purple)

lines(revokeU2_300_U3, col = black, lty=3)
abline(lm(revokeU2_300_U3 ~ xAxis), col = black, lty = 1)
model <- lm(revokeU2_300_U3 ~ xAxis)
text(10, 1300, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=black)

legend(0, 4000, legend=c("Linear Regression With 1 Roles", "Linear Regression With 100 Roles", "Linear Regression With 200 Roles", "Linear Regression With 300 Roles"),
       col=c(blue, green, purple, black), lty=c(1,1,1,1))

dev.off()





# ===== RevokeU3_U1  =====

revokeU3_U1csv <- read.csv(paste(path, "revokeU3_U1.csv", sep=""))

xAxis <- unlist(revokeU3_U1csv[number])
revokeU3_100_U1 <- unlist(revokeU3_U1csv["revokeU3_100_U1"])
revokeU3_200_U1 <- unlist(revokeU3_U1csv["revokeU3_200_U1"])
revokeU3_300_U1 <- unlist(revokeU3_U1csv["revokeU3_300_U1"])

pdf(file = "revokeU3_U1.pdf")

plot(x = xAxis, y = revokeU3_300_U1, ylim=c(0,4000), xlim=c(0,100), cex.axis = 1.5, cex.lab = 1.5, type = "n", xlab = "Number of Other Roles", ylab = "Execution Time (ms)")

lines(actual_revokeU3, col = blue, lty=3) 
abline(lm(actual_revokeU3 ~ xAxis), col = blue, lty = 1)
model <- lm(actual_revokeU3 ~ xAxis)
text(10, 70, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=blue)

lines(revokeU3_100_U1, col = green, lty=3)
abline(lm(revokeU3_100_U1 ~ xAxis), col = green, lty = 1)
model <- lm(revokeU3_100_U1 ~ xAxis)
text(10, 750, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=green)

lines(revokeU3_200_U1, col = purple, lty=3)
abline(lm(revokeU3_200_U1 ~ xAxis), col = purple, lty = 1)
model <- lm(revokeU3_200_U1 ~ xAxis)
text(10, 1350, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=purple)

lines(revokeU3_300_U1, col = black, lty=3)
abline(lm(revokeU3_300_U1 ~ xAxis), col = black, lty = 1)
model <- lm(revokeU3_300_U1 ~ xAxis)
text(10, 1600, trunc(model$coefficients[2]*10^2)/10^2, cex=1.75, pos=3,col=black)

legend(0, 4000, legend=c("Linear Regression With 1 Users", "Linear Regression With 100 Users", "Linear Regression With 200 Users", "Linear Regression With 300 Users"),
       col=c(blue, green, purple, black), lty=c(1,1,1,1))

dev.off()

